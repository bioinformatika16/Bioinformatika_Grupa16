
public class ParGenoma {
	private String prvi, drugi, prviPoravnati, drugiPoravnati;

	private Celija[][] matrica;
	private int matricaRow, matricaCol;
	
	public static int MATCH = 0;
	public static int INSERT = 1;
	public static int DELETE = 2;
	
	public static int CIJENA_PRAZNINE = 1;
	public static int CIJENA_ZAMIJENE = 1;
	
	public ParGenoma(String prvi, String drugi){
		this.prvi = prvi;
		this.drugi = drugi;
	}
	public String[] dohvatiPoravnateGenome(){
		inicijalizirajMatricu();
		popuniTablicu();
		poravnajLance();
		String[] temp = {prviPoravnati, drugiPoravnati};
		return temp;
	}
	private void inicijalizirajMatricu(){
		matricaRow = prvi.length()+1;
		matricaCol = drugi.length()+1;
		matrica = new Celija[matricaRow][matricaCol];
		
		
		
		//inicijalizacija matrice
		for (int i = 0; i <= prvi.length(); i++)
			for (int j = 0; j <= drugi.length(); j++)
				matrica[i][j] = new Celija();

		matrica[0][0].opt = -1;
		//Strupac
		for (int i = 1; i <= prvi.length(); i++){
			matrica[i][0].cijena = i*CIJENA_PRAZNINE;
			matrica[i][0].opt = 2;
		}
		
		//Redak
		for(int i = 1; i <= drugi.length(); i++){
			matrica[0][i].cijena = i*CIJENA_PRAZNINE;
			matrica[0][i].opt = 1;
		}
	}
	
	private void popuniTablicu(){
		int[] opt = new int[3];
		
		//popuni tablicu
		for (int i = 1; i < matricaRow; i++){
			for (int j = 1; j < matricaCol; j++){
				opt[MATCH] = matrica[i-1][j-1].cijena + match(prvi.charAt(i-1), drugi.charAt(j-1));
				opt[INSERT] = matrica[i][j-1].cijena + indel(drugi.charAt(j-1));
				opt[DELETE] = matrica[i-1][j].cijena + indel(prvi.charAt(i-1));
				
				matrica[i][j].cijena = opt[MATCH];
				matrica[i][j].opt = 0;
				
				for (int k = 1; k <= 2; k++){
					if (opt[k] < matrica[i][j].cijena){
						matrica[i][j].cijena = opt[k];
						matrica[i][j].opt = k;
						
					}
						
				}
			}
		}
		//System.out.println(matrica[matricaRow-1][matricaCol-1].cijena);
		
		
	}

	private void poravnajLance(){
		StringBuilder sb1, sb2;
		sb1 = new StringBuilder();
		sb2 = new StringBuilder();
		
		int i,j;
		i = matricaRow - 1;
		j = matricaCol - 1;
		
		//zadnji element matrice
		Celija tempCelija = matrica[i][j];
		
		while(tempCelija.opt != -1){
			
			if (tempCelija.opt == 0){
				sb1.insert(0, prvi.charAt(i-1));
				sb2.insert(0, drugi.charAt(j-1));
				--i;
				--j;
			}
			else if (tempCelija.opt == 1){
				sb1.insert(0, '-');
				sb2.insert(0, drugi.charAt(j-1));
				--j;
			}
			else if (tempCelija.opt == 2){
				sb1.insert(0, prvi.charAt(i-1));
				sb2.insert(0, '-');
				--i;
			}
			else
				System.exit(-1);
			tempCelija = matrica[i][j];
		}
		
		prviPoravnati = sb1.toString();
		drugiPoravnati = sb2.toString();			
	}
	
	
	private int match(char a, char b){
		
		if (a == '-' || b == '-')
			return 0;
		
		if (a == b)
			return 0;
		
		else return CIJENA_ZAMIJENE;
	}
	
	
	private int indel(char a){
		return CIJENA_PRAZNINE;
	}
	
	
}
