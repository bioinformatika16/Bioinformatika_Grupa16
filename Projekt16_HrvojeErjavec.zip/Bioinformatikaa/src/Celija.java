
public class Celija {
	public int cijena = 0;
	//public Celija roditelj = null;
	public int opt = 0;
}
